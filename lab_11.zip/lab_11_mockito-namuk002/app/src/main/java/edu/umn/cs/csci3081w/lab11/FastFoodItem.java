package edu.umn.cs.csci3081w.lab11;

public abstract class FastFoodItem {
  protected int calories = 0;

  public abstract int getCalories();
  public abstract String getDescription();
}
