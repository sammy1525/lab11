package edu.umn.cs.csci3081w.lab11;

public abstract class FastFoodItemFactory {

  public abstract FastFoodItem makeFastFoodItem(String type, String toppings);

}
